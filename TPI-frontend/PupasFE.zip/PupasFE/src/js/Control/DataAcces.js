class DataAccess {
    constructor() {
       this.BASE_URL = "http://localhost:9080/PupasSv-1.0-SNAPSHOT/v1/"; //Ruta real
    }
}
export default DataAccess; //Toda la clase se exporta y se consume de manera externa.